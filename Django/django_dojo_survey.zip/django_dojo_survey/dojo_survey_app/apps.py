from django.apps import AppConfig


class DojoSurveyAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'dojo_survey_app'
