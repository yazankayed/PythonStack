from django.apps import AppConfig


class NinjaAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ninja_App'
