from django.apps import AppConfig


class FruitConfig(AppConfig):
    name = 'fruit'
