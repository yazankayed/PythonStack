from django.apps import AppConfig


class CounterAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'counter_app'
