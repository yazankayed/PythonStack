from django.apps import AppConfig


class LolConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'lol'
