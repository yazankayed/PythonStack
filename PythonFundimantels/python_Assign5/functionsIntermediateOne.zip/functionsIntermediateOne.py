def randInt(min=0,max=100):
    import random
    num = random.randint(min,max)
    print(num)

randInt(min=45)