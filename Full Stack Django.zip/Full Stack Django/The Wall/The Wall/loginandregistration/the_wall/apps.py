from django.apps import AppConfig


class TheWallConfig(AppConfig):
    name = 'the_wall'
